"""Check the temporary open bridge in place of the normal cover."""
import sys,json
from pathlib import Path
sys.path.append('/Applications/FreeCAD.app/Contents/Resources/lib')
import FreeCAD as A
o=Path(__file__).resolve().parents[1];d=A.openDocument(str(o/'cad/SoleSense_R05.FCStd'))
def shape(n):return d.getObject('P_'+n).Shape
bridge=shape('55_Spring_Assembly_Bridge')
checks=[]
for n in ['42_Magnetic_Chassis','44_Moving_Carriage','REF_Service_Pin_M3x25','REF_Lid_Screw_2_1','REF_Lid_Screw_2_2']:
 checks.append({'part':n,'overlap_mm3':bridge.common(shape(n)).Volume})
assert all(c['overlap_mm3']<.01 for c in checks)
(o/'validation/service_fixture.json').write_text(json.dumps(checks,indent=2))
print('ASSEMBLY_BRIDGE_FIT_PASSED')
